<?php $__env->startSection('titulo','Recuerdos'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1 class="display-1 text-center text-danger mt-5"> Recuerdos </h1>    
        
    <?php $__currentLoopData = $consultaRecuerdos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recuerdo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class='container px-5 mt-3'> 
    <div class="card w-50 mt-5">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($recuerdo->titulo); ?> </h5>
          <p class="card-text"><?php echo e($recuerdo->fecha); ?>  </p>
          <p class="card-text"><?php echo e($recuerdo->recuerdo); ?> </p>
          <div class='mb-2 d-grid mx-auto'>
            <button type='button' class='btn btn-outline-success' data-bs-target='#editar<?php echo e($recuerdo->id); ?>' data-bs-toggle='modal'>
              Editar
            </button>
          </div>
          <div class='mb-2 d-grid mx-auto'>
          <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#eliminar<?php echo e($recuerdo->id); ?>">
            Eliminar
         </button>
        </div>

        </div>
      </div>
      
      <?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('partials.modal-delete', ['recuerdo' => $recuerdo], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AMD\laragon\www\Blade-PW-S182\practicalaravel\resources\views/recuerdos.blade.php ENDPATH**/ ?>