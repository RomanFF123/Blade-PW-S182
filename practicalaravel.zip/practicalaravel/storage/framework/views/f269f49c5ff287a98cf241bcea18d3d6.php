<?php $__env->startSection('titulo', 'Recuerdos'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1 class="display-1 text-center text-danger mt-5">Formulario</h1>
    <div class="container mt-5 col-md-6">

      <?php if(session()->has('confirmacion')): ?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong><?php echo e(session('confirmacion')); ?></strong>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endif; ?>

      <?php if($errors->any()): ?> 
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="alert alert-danger alert-dismissible fade show" role="alert">
       <strong><?php echo e($error); ?></strong>
       <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>

      <div class="card text-center">
        <div class="card-header">
          Introduce tus Recuerdos
        </div>
        <div class="card-body">
            <form method="POST" action="/recuerdo">
              <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label class="form-label">Titulo: </label>
                  <input type="text" name="txtTitulo" class="form-control" value=<?php echo e(old('txtTitulo')); ?> >
                  <p class="text-danger fst-italic"><?php echo e($errors->first('txtTitulo')); ?> </p>
                </div>

                <div class="mb-3">
                  <label class="form-label">Recuerdo: </label>
                  <input type="text" name="txtRecuerdo" class="form-control" value= <?php echo e(old('txtRecuerdo')); ?>

                  >
                  <p class="text-danger fst-italic"><?php echo e($errors->first('txtRecuerdo')); ?> </p>
                </div>
        </div>
        <div class="card-footer text-body-secondary">
            <button type="submit" class="btn btn-success">Guardar Recuerdo</button>
        </form> 
        </div>
      </div><!-- Card  -->
    </div> <!-- Contrainer -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AMD\laragon\www\Blade-PW-S182\practicalaravel\resources\views/formulario.blade.php ENDPATH**/ ?>