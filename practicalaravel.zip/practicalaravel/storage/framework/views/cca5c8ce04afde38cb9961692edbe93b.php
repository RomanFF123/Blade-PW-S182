<div class="modal fade" id="eliminar<?php echo e($recuerdo->id); ?>" tabindex="-1" aria-labelledby="eliminarLabel<?php echo e($recuerdo->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
       <div class="modal-content">
          <div class="modal-header">
             <h5 class="modal-title" id="eliminarLabel<?php echo e($recuerdo->id); ?>">Confirmar eliminación</h5>
             <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
             <p>¿Estás seguro de que deseas eliminar este recuerdo?</p>
          </div>
          <div class="modal-footer">
             <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
             <form method="POST" action="<?php echo e(route('recuerdo.destroy', ['id' => $recuerdo->id])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Eliminar</button>
             </form>
          </div>
       </div>
    </div>
 </div>
 <?php /**PATH C:\AMD\laragon\www\Blade-PW-S182\practicalaravel\resources\views/partials/modal-delete.blade.php ENDPATH**/ ?>