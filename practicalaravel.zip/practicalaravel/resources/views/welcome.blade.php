@extends('layouts.plantilla')

@section('titulo','inicio')

@section('contenido')

    <h1 class="display-1 text-center text-danger mt-5"> INICIO </h1>
  
    @endsection
